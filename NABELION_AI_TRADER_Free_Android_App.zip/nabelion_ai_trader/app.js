const $ = id => document.getElementById(id);
const markets = {
 forex:[["EUR/USD","EUR/USD","OANDA:EURUSD"],["GBP/USD","GBP/USD","OANDA:GBPUSD"],["USD/JPY","USD/JPY","OANDA:USDJPY"],["AUD/USD","AUD/USD","OANDA:AUDUSD"]],
 crypto:[["Bitcoin","BTC/USD","BINANCE:BTCUSDT"],["Ethereum","ETH/USD","BINANCE:ETHUSDT"],["Solana","SOL/USD","BINANCE:SOLUSDT"],["XRP","XRP/USD","BINANCE:XRPUSDT"]],
 stocks:[["Apple","AAPL","NASDAQ:AAPL"],["Microsoft","MSFT","NASDAQ:MSFT"],["Nvidia","NVDA","NASDAQ:NVDA"],["Tesla","TSLA","NASDAQ:TSLA"]],
 commodities:[["Gold","XAU/USD","OANDA:XAUUSD"],["Silver","XAG/USD","OANDA:XAGUSD"],["Crude Oil","WTI","TVC:USOIL"]],
 indices:[["S&P 500","SPX","SP:SPX"],["NASDAQ 100","NDX","NASDAQ:NDX"],["Dow Jones","DJI","DJ:DJI"]]
};
let interval="15min", lastAnalysis=null;
function populate(){
 const cat=$("category").value, sel=$("symbol"); sel.innerHTML="";
 markets[cat].forEach(([label,symbol])=>{const o=document.createElement("option");o.value=symbol;o.textContent=label;sel.appendChild(o)});
}
$("category").addEventListener("change",populate);populate();
$("timeframes").addEventListener("click",e=>{const b=e.target.closest("button[data-interval]");if(!b)return;interval=b.dataset.interval;document.querySelectorAll(".timeframes button").forEach(x=>x.classList.toggle("selected",x===b));});
const savedKey=localStorage.getItem("nabelion_td_key")||"";$("apiKey").value=savedKey;
$("keyStatus").textContent=savedKey?"API key saved on this phone.":"No API key saved.";
$("saveKey").onclick=()=>{const k=$("apiKey").value.trim();if(!k){$("keyStatus").textContent="Paste your key first.";return}localStorage.setItem("nabelion_td_key",k);$("keyStatus").textContent="Key saved in this browser on this phone."};
$("clearKey").onclick=()=>{localStorage.removeItem("nabelion_td_key");$("apiKey").value="";$("keyStatus").textContent="API key cleared."};

function ema(values,period){let k=2/(period+1),v=values[0];for(let i=1;i<values.length;i++)v=values[i]*k+v*(1-k);return v}
function rsi(values,p=14){let gains=0,losses=0;for(let i=values.length-p;i<values.length;i++){let d=values[i]-values[i-1];if(d>0)gains+=d;else losses-=d}let ag=gains/p,al=losses/p;if(al===0)return 100;return 100-100/(1+ag/al)}
function atr(rows,p=14){let trs=[];for(let i=1;i<rows.length;i++){let x=rows[i],prev=rows[i-1];trs.push(Math.max(x.high-x.low,Math.abs(x.high-prev.close),Math.abs(x.low-prev.close)))}return trs.slice(-p).reduce((a,b)=>a+b,0)/Math.min(p,trs.length)}
function macd(values){return ema(values,12)-ema(values,26)}
function macdHistogram(values){
 const series=[];
 for(let i=25;i<values.length;i++){
   const part=values.slice(0,i+1);
   series.push(ema(part,12)-ema(part,26));
 }
 if(series.length<9)return 0;
 return series.at(-1)-ema(series,9);
}
function fmt(n){if(!Number.isFinite(n))return "—";return n.toLocaleString(undefined,{maximumFractionDigits:5})}
function renderChart(){
 const item=markets[$("category").value].find(x=>x[1]===$("symbol").value);
 const tvSymbol=item?item[2]:"OANDA:EURUSD";
 const tvInterval=({"1min":"1","5min":"5","15min":"15","1h":"60","4h":"240"})[interval];
 $("chart").innerHTML=`<iframe title="TradingView chart" loading="lazy" src="https://www.tradingview.com/widgetembed/?frameElementId=tv_chart&symbol=${encodeURIComponent(tvSymbol)}&interval=${tvInterval}&hidesidetoolbar=1&symboledit=1&saveimage=0&toolbarbg=0f172a&studies=[]&theme=dark&style=1&timezone=Etc%2FUTC&withdateranges=1&hideideas=1&hidevolume=0&allow_symbol_change=1&details=0&hotlist=0&calendar=0" allowfullscreen></iframe>`;
}
$("openChart").onclick=renderChart;

$("analyse").onclick=async()=>{
 const key=localStorage.getItem("nabelion_td_key"),symbol=$("symbol").value;
 if(!key){$("reason").textContent="Connect a free Twelve Data API key to retrieve candles. You can still open the TradingView chart."; $("signal").textContent="WAIT";$("signalCard").className="signal-card neutral";return}
 $("analyse").disabled=true;$("analyse").textContent="Loading…";
 try{
  const url=`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=120&apikey=${encodeURIComponent(key)}`;
  const res=await fetch(url);const data=await res.json();
  if(!res.ok||data.status==="error"||!data.values)throw new Error(data.message||"No candle data returned. Check symbol, interval, API key and free-plan access.");
  const rows=data.values.slice().reverse().map(x=>({open:+x.open,high:+x.high,low:+x.low,close:+x.close}));
  if(rows.length<35)throw new Error("Not enough historical candles to calculate the indicators.");
  const closes=rows.map(x=>x.close), price=closes.at(-1), e9=ema(closes.slice(-80),9),e21=ema(closes.slice(-100),21),rv=rsi(closes),mv=macd(closes),av=atr(rows);
  const hist=macdHistogram(closes);
  let score=0; if(e9>e21)score++;else score--;if(rv>52&&rv<70)score++;else if(rv<48&&rv>30)score--;if(mv>0)score++;else score--;if(hist>0)score++;else score--;
  const trend=e9>e21?"BULLISH":e9<e21?"BEARISH":"MIXED";
  const signal=score>=3?"BUY WATCH":score<=-3?"SELL WATCH":"WAIT";
  const sup=Math.min(...rows.slice(-20).map(x=>x.low)),res=Math.max(...rows.slice(-20).map(x=>x.high));
  const direction=signal.startsWith("BUY")?1:signal.startsWith("SELL")?-1:0;
  const stop=direction?price-direction*1.5*av:null,target=direction?price+direction*3*av:null;
  $("signal").textContent=signal;$("signalCard").className="signal-card "+(direction>0?"bull":direction<0?"bear":"neutral");
  $("reason").textContent=`${trend} EMA structure; RSI ${fmt(rv)}; MACD ${fmt(mv)}. Score ${score}/4. Wait for price-action confirmation.`;
  $("updated").textContent=`Latest candle: ${data.values[0].datetime} · ${interval}`;
  $("price").textContent=fmt(price);$("rsi").textContent=fmt(rv);$("ema").textContent=`${fmt(e9)} / ${fmt(e21)}`;$("macd").textContent=fmt(mv);$("atr").textContent=fmt(av);$("trend").textContent=trend;
  $("support").textContent=fmt(sup);$("resistance").textContent=fmt(res);$("stop").textContent=stop?fmt(stop):"No setup";$("target").textContent=target?fmt(target):"No setup";
  $("explanation").textContent="Rule-based educational signal only. EMA/RSI/MACD agreement is not enough by itself: check spread, news, session, support/resistance and your broker's price before any trade.";
  lastAnalysis={price,signal,stop,target,atr:av,interval,symbol};
 }catch(err){$("signal").textContent="DATA ERROR";$("signalCard").className="signal-card neutral";$("reason").textContent=err.message;$("updated").textContent="Try another symbol or timeframe, or check your API limit."}
 finally{$("analyse").disabled=false;$("analyse").textContent="Analyse market"}
};
$("calcRisk").onclick=()=>{const bal=Number($("balance").value),pct=Number($("riskPct").value);if(bal<=0||pct<=0||pct>5){$("riskOutput").textContent="Enter a positive balance and risk between 0.1% and 5%.";return}$("riskOutput").textContent=`Risk budget: $${(bal*pct/100).toFixed(2)} (${pct}% of $${bal.toFixed(2)}).`};
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
